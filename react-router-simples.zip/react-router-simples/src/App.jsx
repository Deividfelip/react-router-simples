import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Login from './pages/Login';
import Inicio from './pages/Inicio';
import Tarefas from './pages/Tarefas';
import DetalheTarefa from './pages/DetalheTarefa';
import Sobre from './pages/Sobre';
import NaoEncontrada from './pages/NaoEncontrada';

function App() {
  const [tarefas, setTarefas] = useState([]);

  function adicionar(novaTarefa) {
    setTarefas([...tarefas, { id: Date.now(), ...novaTarefa }]);
  }

  function remover(id) {
    setTarefas(tarefas.filter((tarefa) => tarefa.id !== id));
  }

  function editar(id) {
    const tarefaAtual = tarefas.find((t) => t.id === id);
    const novoNome = prompt('Novo nome da tarefa:', tarefaAtual ? tarefaAtual.nome : '');

    if (novoNome === null || novoNome.trim() === '') return;

    setTarefas(
      tarefas.map((tarefa) =>
        tarefa.id === id ? { ...tarefa, nome: novoNome } : tarefa
      )
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route path="/" element={<Layout />}>
        <Route index element={<Inicio total={tarefas.length} />} />
        <Route
          path="tarefas"
          element={
            <Tarefas
              tarefas={tarefas}
              onAdicionar={adicionar}
              onRemover={remover}
              onEditar={editar}
            />
          }
        />
        <Route
          path="tarefas/:id"
          element={<DetalheTarefa tarefas={tarefas} onRemover={remover} />}
        />
        <Route path="sobre" element={<Sobre />} />
        <Route path="*" element={<NaoEncontrada />} />
      </Route>
    </Routes>
  );
}

export default App;