function Inicio({ total }) {
  return (
    <div>
      <h1>Bem-vindo!</h1>
      <p>Você tem {total} tarefa(s) cadastrada(s).</p>
    </div>
  );
}

export default Inicio;