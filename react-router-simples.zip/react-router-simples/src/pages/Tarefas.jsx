import { useState } from 'react';
import ItemTarefa from '../components/ItemTarefa';

function Tarefas({ tarefas, onAdicionar, onRemover, onEditar }) {
  const [mostrarFormulario, setMostrarFormulario] = useState(false);

  const [nome, setNome] = useState('');
  const [importancia, setImportancia] = useState('Média');
  const [resumo, setResumo] = useState('');
  const [prazo, setPrazo] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (nome.trim() === '') return;

    onAdicionar({
      nome,
      importancia,
      resumo,
      prazo,
    });

    setNome('');
    setImportancia('Média');
    setResumo('');
    setPrazo('');
    setMostrarFormulario(false);
  }

  return (
    <div className="container-fluid px-4 py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      
      {/* Alerta de Boas-vindas / Status (Estilo Portal) */}
      <div className="alert alert-success border-0 shadow-sm d-flex justify-content-between align-items-center mb-4 py-3 rounded-3" role="alert">
        <div>
          <strong>Painel Acadêmico / Tarefas:</strong> Gerencie suas entregas e prazos com facilidade.
        </div>
        <span className="badge bg-success text-white px-3 py-2 rounded-pill">
          {tarefas.length} {tarefas.length === 1 ? 'pendência ativa' : 'pendências ativas'}
        </span>
      </div>

      {/* Cabeçalho da Seção com Botão de Ação */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold text-dark mb-1">Lista de Tarefas</h2>
          <p className="text-muted small mb-0">Acompanhe e organize suas atividades diárias.</p>
        </div>
        <button
          className={`btn ${mostrarFormulario ? 'btn-outline-secondary' : 'btn-primary'} px-4 py-2 shadow-sm rounded-pill fw-semibold`}
          onClick={() => setMostrarFormulario(!mostrarFormulario)}
        >
          {mostrarFormulario ? 'Cancelar' : '+ Nova Tarefa'}
        </button>
      </div>

      {/* Formulário Estilo Cartão Institucional */}
      {mostrarFormulario && (
        <div className="card border-0 shadow-sm p-4 mb-4 bg-white rounded-3">
          <h5 className="fw-bold text-secondary mb-3 border-bottom pb-2">Cadastrar Nova Atividade</h5>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label text-muted small fw-bold">NOME DA TAREFA</label>
              <input
                type="text"
                className="form-control bg-light border-0 py-2"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Ex: Entrega do Projeto Final"
                required
              />
            </div>

            <div className="row">
              <div className="col-md-6 mb-3">
                <label className="form-label text-muted small fw-bold">IMPORTÂNCIA</label>
                <select
                  className="form-select bg-light border-0 py-2"
                  value={importancia}
                  onChange={(e) => setImportancia(e.target.value)}
                >
                  <option value="Baixa">🟢 Baixa</option>
                  <option value="Média">🟡 Média</option>
                  <option value="Alta">🔴 Alta</option>
                </select>
              </div>

              <div className="col-md-6 mb-3">
                <label className="form-label text-muted small fw-bold">PRAZO DE ENTREGA</label>
                <input
                  type="date"
                  className="form-control bg-light border-0 py-2"
                  value={prazo}
                  onChange={(e) => setPrazo(e.target.value)}
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="form-label text-muted small fw-bold">DESCRIÇÃO / TÓPICOS</label>
              <textarea
                className="form-control bg-light border-0"
                rows="3"
                value={resumo}
                onChange={(e) => setResumo(e.target.value)}
                placeholder="Digite os detalhes da tarefa (use Enter para pular linhas)..."
              ></textarea>
            </div>

            <div className="d-flex justify-content-end gap-2">
              <button
                type="button"
                className="btn btn-light px-4 text-muted fw-semibold"
                onClick={() => setMostrarFormulario(false)}
              >
                Fechar
              </button>
              <button type="submit" className="btn btn-primary px-4 fw-semibold shadow-sm">
                Salvar Tarefa
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Bloco de Avisos / Lista de Tarefas */}
      <div className="card border-0 shadow-sm bg-white rounded-3 p-4">
        <h5 className="fw-bold text-dark mb-3 border-bottom pb-2">📋 Atividades Registradas</h5>

        {tarefas.length === 0 ? (
          <div className="text-center py-5">
            <p className="text-muted mb-0">Não há nenhuma tarefa cadastrada neste momento.</p>
          </div>
        ) : (
          <div className="d-flex flex-column gap-3">
            {tarefas.map((tarefa) => (
              <ItemTarefa
                key={tarefa.id}
                tarefa={tarefa}
                onRemover={onRemover}
                onEditar={onEditar}
              />
            ))}
          </div>
        )}
      </div>

    </div>
  );
}

export default Tarefas;