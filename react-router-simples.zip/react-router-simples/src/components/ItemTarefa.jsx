import { Link } from 'react-router-dom';

function ItemTarefa({ tarefa, onRemover, onEditar }) {
  // Cores institucionais para o badge de importância
  const badgeClass =
    tarefa.importancia === 'Alta'
      ? 'bg-danger text-white'
      : tarefa.importancia === 'Média'
      ? 'bg-warning text-dark'
      : 'bg-secondary text-white';

  return (
    <div className="p-3 bg-light rounded-3 border border-light shadow-sm d-flex justify-content-between align-items-start gap-3">
      <div className="flex-grow-1">
        <div className="d-flex align-items-center gap-2 mb-1">
          <Link
            to={`/tarefas/${tarefa.id}`}
            className="fw-bold text-primary text-decoration-none fs-6"
          >
            {tarefa.nome}
          </Link>
          <span className={`badge ${badgeClass} small px-2 py-1`}>
            {tarefa.importancia}
          </span>
        </div>

        {tarefa.resumo && (
          <p
            className="text-secondary small mb-2 bg-white p-2 rounded border border-white"
            style={{ whiteSpace: 'pre-line' }}
          >
            {tarefa.resumo}
          </p>
        )}

        {tarefa.prazo && (
          <div className="text-muted" style={{ fontSize: '0.85rem' }}>
            📅 <strong>Prazo:</strong> {tarefa.prazo.split('-').reverse().join('/')}
          </div>
        )}
      </div>

      <div className="d-flex gap-2">
        <button
          className="btn btn-sm btn-outline-primary px-3 rounded-2"
          onClick={() => onEditar(tarefa.id)}
          title="Editar"
        >
          Editar
        </button>
        <button
          className="btn btn-sm btn-outline-danger px-3 rounded-2"
          onClick={() => onRemover(tarefa.id)}
          title="Excluir"
        >
          Excluir
        </button>
      </div>
    </div>
  );
}

export default ItemTarefa;